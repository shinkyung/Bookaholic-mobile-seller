package com.example.bookaholic.details;

public class ImageDetail {
    private int imageID;

    public ImageDetail() {
        // Do nothing here
    }

    public ImageDetail(int imageID) {
        this.imageID = imageID;
    }
    public int getImageID() {
        return imageID;
    }

    public void setImageID(int imageID) {
        this.imageID = imageID;
    }

}
