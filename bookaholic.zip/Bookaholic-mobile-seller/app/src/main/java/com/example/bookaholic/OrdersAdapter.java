package com.example.bookaholic;

public class OrdersAdapter {
}
